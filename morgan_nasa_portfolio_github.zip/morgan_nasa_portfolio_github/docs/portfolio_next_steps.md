# Portfolio Next Steps

## Phase 1: Set up repository

- Create a new GitHub repository.
- Upload this folder.
- Keep the repository public only if it contains no sensitive data.
- Update the root README with your public LinkedIn or website.

## Phase 2: Build first project

Recommended first project: `03_remote_sensing_worldview_case_study`

Why: It is fast, visible, and directly supports the NASA ARSET certificate.

## Phase 3: Build strongest NASA-facing project

Recommended second project: `01_earth_observation_human_performance`

Why: It connects Earth observation to human performance, space medicine, operational medicine, and environmental exposure.

## Phase 4: Add job application evidence

For each project, create:
- README
- 1 figure
- 1 short project brief
- 1 limitation section
- 1 user need/application section

## Public portfolio rule

No identifiable participant data. No employer-owned material. No CUI. No private clinical documents. No raw study files. We are trying to get hired, not summoned into a compliance meeting.
