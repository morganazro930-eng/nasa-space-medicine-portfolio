# How to Upload This Folder to GitHub

## Option 1: GitHub website

1. Go to GitHub.
2. Create a new repository.
3. Suggested name: `nasa-space-medicine-portfolio`
4. Keep it public only if you are sure there is no sensitive information.
5. Upload the folder contents.
6. Commit changes with the message: `Initial portfolio structure`.

## Option 2: Command line

```bash
git init
git add .
git commit -m "Initial NASA space medicine portfolio structure"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/nasa-space-medicine-portfolio.git
git push -u origin main
```

## Suggested repository description

NASA / space medicine portfolio connecting human performance, wearable biometric data, neurotechnology, operational medicine, Earth observation, and open science.
