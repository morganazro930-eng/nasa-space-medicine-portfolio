# Project 4: Space Medicine Literature Matrix

## Purpose

Track literature on space medicine, human adaptation, human performance, neurotechnology, rehabilitation systems, sleep, inflammation, and operational physiology.

## How to use

Add papers to `literature_matrix.csv` and summarize why each paper matters for NASA human research or space medicine.

## Recommended tags

- Sleep
- Neurocognition
- Pain
- Fatigue
- Immune adaptation
- Microgravity
- Countermeasures
- Wearables
- Human factors
- Operational medicine
- Rehabilitation
- Sensorimotor adaptation
