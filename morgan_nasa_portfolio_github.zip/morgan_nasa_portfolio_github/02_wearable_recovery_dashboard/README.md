# Project 2: Wearable Recovery Dashboard

## Purpose

Create a mock dashboard concept for sleep, recovery, and human performance data using wearable-style metrics.

## NASA / space medicine relevance

Sleep, recovery, fatigue, physiological strain, and neurocognitive performance are central to crew health, operational medicine, and mission readiness.

## Example metrics

- Sleep duration
- Sleep efficiency
- Resting heart rate
- Heart rate variability
- Recovery score
- Pain score
- Fatigue score
- Mobility or walking assessment outcome

## Planned outputs

- Synthetic dataset
- Dashboard sketch
- Python visualization notebook
- One-page interpretation guide
