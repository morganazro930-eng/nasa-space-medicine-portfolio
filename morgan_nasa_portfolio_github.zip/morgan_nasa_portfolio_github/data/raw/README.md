# Raw data

Do not upload real participant data, identifiable data, PHI, CUI, controlled research records, employer files, or non-public federal/DoD data.

Use only:
- NASA open data
- Public datasets
- Synthetic/mock datasets
- De-identified educational examples with permission
