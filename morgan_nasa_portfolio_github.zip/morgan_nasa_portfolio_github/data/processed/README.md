# Processed data

Store cleaned public or synthetic datasets here.

Recommended naming format:
`YYYY-MM-DD_project_dataset_version.csv`
