# Project 1: Earth Observation + Human Performance

## Purpose

Explore how NASA Earth observation data can support human performance, operational medicine, and space medicine questions by connecting environmental exposure variables to physiological or behavioral outcomes.

## Research question

How might environmental stressors such as heat, smoke, humidity, air quality, flooding, or land cover change affect sleep, recovery, mobility, pain, neurocognitive performance, or operational readiness?

## NASA relevance

This project supports a NASA-adjacent human research lens by treating extreme environments on Earth as analogs for studying human adaptation, resilience, and decision support.

## Possible datasets

- NASA Earthdata
- NASA Worldview imagery
- NASA FIRMS active fire detections
- MODIS / VIIRS environmental products
- NOAA weather or air quality datasets
- Public heat index, PM2.5, wildfire smoke, or flood datasets

## Planned workflow

1. Define a user need.
2. Select an environmental exposure variable.
3. Identify a public Earth observation dataset.
4. Link exposure data to synthetic or public health/performance outcomes.
5. Create visualizations and a short decision-support summary.
6. Document limitations and next steps.

## Planned outputs

- One-page project brief
- Jupyter notebook or Python script
- Clean README
- Small figure set
- Decision-support summary
