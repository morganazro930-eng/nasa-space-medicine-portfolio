# Project 3: NASA Worldview Case Study

## Purpose

Use NASA Worldview imagery to create a short case study showing how satellite imagery supports environmental monitoring and decision-making.

## Possible case study themes

- Wildfire and smoke
- Flooding and vegetation impact
- Urban heat or heat islands
- Drought and vegetation stress
- Dust, aerosols, or air quality
- Hurricane or storm impacts

## Recommended structure

1. Event overview
2. Area of interest
3. Sensors/layers used
4. What the imagery shows
5. Why it matters for decision-making
6. Limitations
7. Connection to health, human performance, or operational readiness
